#include <nmlib/model/moduleinput.hpp>

namespace nm {
} // namespace nm
