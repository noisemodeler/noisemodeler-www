#include "defaultsgenerator.hpp"

namespace nm {
} // namespace nm
