#include "simplebodygenerator.hpp"

namespace nm {
} // namespace nm
