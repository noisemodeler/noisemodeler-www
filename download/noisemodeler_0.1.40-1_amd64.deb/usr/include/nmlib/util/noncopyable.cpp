#include "noncopyable.hpp"

namespace nm {
} // namespace nm
