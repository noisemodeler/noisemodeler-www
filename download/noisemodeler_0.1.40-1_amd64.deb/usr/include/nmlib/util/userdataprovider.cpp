#include <nmlib/util/userdataprovider.hpp>

namespace nm {
} // namespace nm
